__version__ = '1.2.2.dev20260706+ba07dce9'
